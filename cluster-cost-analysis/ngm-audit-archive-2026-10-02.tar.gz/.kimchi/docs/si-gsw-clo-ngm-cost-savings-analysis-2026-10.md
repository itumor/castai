# NGM EKS clusters (SI GSW CLO) — real cost, CAST AI savings proof, and tuning plan

**Date:** 2026-10-02 · **Analyst:** CAST AI Support (database of live API reads, all raw JSON retained)
**Scope:** `ngm-helios-eks`, `ngm-integ-eks`, `ngm-kronos-eks` — org **SI GSW CLO** (`07aa3c29-3e1f-44bc-ad60-ceedb878d99a`), EKS `eu-central-1`, AWS account `600442974479`. All three on the same account.
**Hard constraints honored:** no workload autoscaler (WOOP) recommendations as a requirement; spot modeled as an *offer*, not an assumption; node template / node configuration tuning is the main axis, per request.

---

## 1. Executive summary

**Verdict: CAST AI is beneficial on all three clusters — demonstrably, on three independent calculation methods.** The "no savings" impression is the classic workload-growth + provisioning-mode optical trap, not a measurement of reality.

| Cluster | Autoscaler live since | W30 actual spend (discounted) | CAST AI realized (their API, monthly rate) | **Conservative net (M1, fee-included, monthly)** | ER (current ÷ baseline unit price) |
|---|---|---|---|---|---|
| `ngm-helios-eks` | 2026-07-20 | **$53.4k** | $20.2k/mo | **$7.1k/mo** | 0.86 |
| `ngm-integ-eks` | 2026-04-27 | **$23.8k** | $19.5k/mo | **$8.9k/mo** | 0.70 |
| `ngm-kronos-eks` | 2025-11-06 | **$2.3k** | $2.1k/mo | **$1.1k/mo** | 0.62 |
| **Σ** | | **$79.5k/mo** | **$41.9k/mo** | **$17.1k/mo** | — |

- **CAST AI's own realized savings**: $125.6k over the last 90 days across the three clusters, 100% from downscaling, **$0 from spot** (spot is disabled cluster-wide by policy).
- **Independent frozen-baseline method** (the Siemens-agreed methodology): even at the most conservative counterfactual, net-of-fee savings are **~$17.1k/mo**. Every cluster's true number sits *between* the conservative floor and CAST AI's realized number. Range shown, never blended.
- **Why the customer sees "nothing"**: demand grew while AUTOSCALING ran — helios +13% vCPU month-on-month, integ swings 44→838 nodes *per day* (integration-test bursts). Absolute bills grow; **unit cost fell 14–38%**. The AWS bill does not show the counterfactual.

**What they can still capture without WOOP (what-if, ranges):** conservative $19k/mo → high $36k/mo on top of current savings, and up to $48k/mo gross on helios-only at full spot per CAST AI's own snapshot. Details in §6. And the elephant: **requests run at 7–13× actual usage** — the WOOP refusal costs roughly **$28–52k/mo** of forfeited headroom (§6.4).

---

## 2. Method & data sources (all read-only, reproducible)

- Window **W30** = 2026-09-02 → 2026-10-01 (30 full days, today dropped); **W90** = 2026-07-04 → 2026-10-02.
- Endpoints (EU base `https://api.eu.cast.ai`, header `X-CastAI-Organization-Id: 07aa3c29-…`, `X-API-Key` auth): `/v1/cost-reports/clusters/{id}/cost|resource-usage|savings|estimated-savings|node-count-history|nodes/storage`, `/v1/kubernetes/clusters/{id}/policies|node-configurations|node-templates|rebalancing-plans|problematic-nodes`, `/v1/kubernetes/external-clusters(/{id}/nodes)`, `/reporting/v1beta/organizations/{org}/clusters/{id}/baseline-params`, `/v1/workload-autoscaling/clusters/{id}/workloads-summary`, `/v1/audit`.
- Savings engine: `scripts/savings/savings_report.py` (frozen-baseline M1 + two-resource TR + M2 gates; switch dates resolved from CAST AI `baseline-params`). Output table: `.kimchi/docs/si-gsw-clo-ngm-savings-clustermonth.csv`.
- Cost basis: **discounted** (≈ bill-adjacent) for all "actual" numbers. CAST AI's `estimated-savings` scenarios quote **listing prices** and are labeled as such wherever used. Fee: 5% of positive gross savings (Siemens contract assumption — confirm).
- Raw API responses archived per cluster under `cluster-cost-analysis/ngm-*/` (≈25 JSON files each).
- Known flags: kronos baseline n=37 days (short — low confidence, CV 0.13); M2 gates failed on all three (CPU/RAM collinear → M1+TR reported); helios `CALIBRATION_FAIL` flag investigated and resolved — the `/cost` endpoint returns avg-**hourly** items and ×24h reproduces `summary.totalCost` exactly ($74.13/h × 720 h = $53,376.62 ✓).

---

## 3. Per-cluster findings

### 3.1 ngm-helios-eks — the flagship ($53.4k/mo, 33% of org spend)

**State.** 300 nodes (292 CAST-AI-managed, `addedBy: internal|autoscaler`; **no Karpenter anywhere**), all on-demand, all amd64 (zero Graviton/ARM), zones `eu-central-1a/1b` only. Fleet: m6a ×150, r6a ×90, c5a/c6a/c5ad ×52, m7a ×8. **~16% of nodes are leftover c5a 5th-gen.** Sampled nodes join timestamps show continuous healthy churn (autoscaler + one nightly scheduled rebalancing plan `ngm-helios-castai-hourly-nightly`).

**Cost anatomy (W30, discounted).** Total $53,377 → compute CPU $26.5k + RAM $18.1k + **storage $8.8k** (avg **93.6 TiB** provisioned; node root volumes = 300 × 100 GiB gp3 ≈ 30 TiB → **≈64 TiB is attached EBS/PVs**). Blended $0.85/vCPU·day today vs frozen baseline $0.98 → ER 0.86. Avg 1,774 vCPU / 8.2 TiB RAM provisioned.

**Utilization (the painful part).** cpuUsed avg **163 vCPU of 1,774 provisioned = 9.2%** (RAM 21.8%). Requests 75.6% of provisioned — CAST AI already packs to requests. WOOP telemetry: pod-level requests 2,052 cores vs **usage 279 cores (7.3×)**, WOOP recommends 473.

**Savings evidence.** Switch 2026-07-20 (only ~74 days live). CAST AI realized W90: **$60,734 on $138,634 spend (≈$20.2k/mo), 100% downscaling, spot $0**. Frozen-baseline M1 Sep net **$6.6k → ~$7.1k/mo** (TR $6.5k agrees). Pre-switch overprovisioning factor 1.60 → today prov:req 1.32. `isRebalancingRecommended: true` — CAST AI's own snapshot (listing basis): current $68.4k/mo → Layman $54.5k (−20.4%) → SpotInstances $51.8k (−24.3%) → **SpotOnly $20.1k (−70.7%)**; the Live spot price in that plan (m6a.24xlarge $1.109/h vs OD $2.982/h) is a **−62.8% real discount**, which anchors the §6 spot math on observed prices, not a brochure figure.

**Issues found.** (a) `spotInstances.enabled=false`; (b) **evictor `Incompatible´ — enabled but `allowed=false`** (docs: this is the "Evictor installed but not managed by CAST AI" detection — a self-managed helm install blocks CAST AI from governing bin-packing); interim mitigation = the nightly rebalancing schedule; (c) 8 nodes labeled `autoscaling.cast.ai/removal-disabled` (block bin-packing); (d) interruption prediction still typed `AWSRebalanceRecommendations` (deprecated 2026-07 → auto-migrates to CAST AI ML model, cosmetic); (e) WOOP agent v1.10.4 vs latest v1.14.1 (metrics mode only, applies nothing — `optimizedCount: 0`); (f) 2-AZ-only subnets; (g) one rebalancing plan errored 10:04 today among 50 plans/30d (33 "generated-not-executed": below-threshold guards).

### 3.2 ngm-integ-eks — the volatile test cluster ($23.8k/mo)

**State.** 78 nodes at probe time, but **node count swings 44 → 838 on-demand nodes within days** (node-count history Sep 25 → Oct 1: 712 / 163 / 44 / 514 / 677 / 838 / 601). This is an integration-test burst workload. 68/78 CAST-AI-managed, all on-demand, all amd64, 2 AZs. Mix: m6a ×57, r6a ×6, c5a/c6a/c7i-flex ×15.

**Cost anatomy (W30).** Total $23,835 incl. $1.8k storage. Provisioned avg 1,021 vCPU vs requested 647 (63.4%). cpuUsed **67 vCPU → 6.6% utilization**; pod-level requests 430 cores vs usage 32.5 (**13.2×**).

**Savings evidence.** Switch 2026-04-27. CAST AI realized W90: **$58,419 on $64,384 spend (≈$19.5k/mo —historic overprovisioning factor was 2.20×**, so the empty-fleet cleanup between bursts is the entire realized story and it is big). M1 Sep net $8.3k → **~$8.9k/mo**, TR $7.6k. 42 rebalancing plans in W30 — **8 errored with a hard structural reason**: `no instance types are available to fit this pod: persistentvolumeclaim…` for `scada-dp-server-*` and `valkey-cluster-node-*` — **zone-pinned PVC stateful workloads** block node creation during rebalances on the 2-AZ substrate. Also captured live: an `InsufficientCapacity` failure adding on-demand `c5a.4xlarge` in `eu-central-1a` — on-demand pool exhaustion at burst time.

**Issues found.** (a) spot disabled (on the *most spot-suitable cluster* in the org — batch/test, high churn, short node lifetimes); (b) evictor `Incompatible` — for a 600-840-node burst fleet, when re-enabling also set `maxTargetNodesPerCycle=5` and `cycleInterval=10m` per CAST AI's 500+ node guidance; (c) 10 `removal-disabled` nodes; (d) PVC-zone-pinned stateful pods blocking plans (needs storage/topology decision, see §7); (e) `clusterLimits.maxCores=16384` on a cluster that bursts to ~840 nodes — add a real guardrail (governance, not autoscaling).

### 3.3 ngm-kronos-eks — the small finished one ($2.3k/mo)

**State.** 14 nodes (13 managed), all on-demand amd64, 2 AZs; mix m6a/r6a/c5a/c6a/m7a. Avg 86 vCPU provisioned, req 59, **cpuUsed 5 vCPU → 5.8%**; pod requests 115 cores vs usage 13.1 (8.8×).

**Savings evidence.** Switch 2025-11-06 (~11 months live — but only 37 days of read-only baseline existed, onboarding 30 Sep → switch 6 Nov; treat its frozen price $1.20/vCPU·day as lower-confidence, CV 0.13). CAST AI realized W90: **$6,401 on $4,202 spend (≈$2.1k/mo, 60% of the projected counterfactual)** — historic overprovisioning was **5.25×**; CAST AI crushed idle standby fleets. M1 Sep net $1.03k → **~$1.1k/mo**.
Note: 19 of 50 W30 rebalancing plans ended in "error" — root cause read and **benign**: `achievedSavingsBelowThreshold` (the rebalancer looks, finds nothing worth doing at 14 nodes, and correctly skips). No action except cosmetics. Demand has a strong weekly cycle: the fleet collapses to ~14 vCPU / ~64 GiB on weekends (verified in the daily series; ~$21–27/day weekends vs $85–144 weekdays) — smol cluster, well-behaved downscaling.

**Issues found.** Same policy DNA: spot off, evictor `Incompatible`, 1 removal-disabled node, WOOP metrics-only. Estimated snapshot: current $3.8k/mo listing → SpotOnly $1.18k (−69%).

---

## 4. Cross-cluster configuration audit (the "check the configuration, right?" part — verified against API and docs)

All three clusters share one node configuration per cluster (`ngm-<cluster>-castai`) and **zero custom node templates** — everything flows through `default-by-castai` (template versions 8–21, so fields *have* been iterated).

| Knob | Current state (all 3) | Assessment |
|---|---|---|
| `spotInstances.enabled` | **false** | **#1 lever.** Spot 0% fleet-wide; spot backups/predictions already configured (ready to flip) |
| Interruption prediction | `AWSRebalanceRecommendations` | Deprecated (Jul 2026): auto-migrates to CAST AI ML model; update config cosmetically |
| Evictor | enabled, **`status=Incompatible, allowed=false`** | **#2 lever.** Self-managed helm install detected → CAST AI can't govern bin-packing. Fix ownership or align values |
| `emptyNodes.delaySeconds` | 90 | Good — aggressive empty cleanup |
| `headroom` | null → platform default | Provisioned:requested sits 1.32–1.58 — no evidence of excessive explicit headroom; leave |
| `clusterLimits` | maxCores 16384 | Meaningless ceiling; set real guardrails (esp. integ bursts) |
| Node configs | gp3 ✓, IMDSv2 ✓, containerd ✓, custom KMS ✓ | Healthy. But: **pinned AMI `ami-0706…`** (no image family → ages; CLM needs AL2023+containerd), **2 subnets → 2 AZs only** |
| Instance families | m6a/r6a dominant; **c5a 5th-gen slice remains** (16% of helios) | Add family priority tiers (m6a/m7a/c6a/c7a over c5a) or blocklist c5a; also fixes the observed c5a InsufficientCapacity adds |
| Zones | 1a + 1b only | Add `eu-central-1c` subnets → more on-demand capacity pools (today's live InsufficientCapacity) AND a much deeper spot inventory |
| `removal-disabled` nodes | 8 / 10 / 1 | Each one freezes its instance + blocks packing; review with owners |
| WOOP agent | installed v1.10.4, **optimizedCount 0** (metrics only) | Satisfies "no WOOP" de facto; version drift → bump to v1.14.1 for telemetry accuracy |
| Rebalancing | schedules active (hourly/nightly) | Working; kronos "errors" are benign below-threshold skips; integ errors = PVC-zone blockers to fix |

---

## 5. Why the customer thinks "CAST AI saves nothing" — and why they're wrong

Three numbers exist simultaneously; they measure different things. **Never blend them; show all three.**

1. **Naive absolute delta (what the customer sees in the invoice):** the bill grew — because *workload* grew (helios 1,759 → 1,991 avg vCPU Sep→Oct; integ bursts hard). This view has no counterfactual and always looks bad during growth.
2. **Frozen read-only prices (our Siemens method):** "what today's demand would have cost at the unit prices measured immediately before CAST AI started acting": Sep adjusted baseline $30.9k + $2.9k + $48.4k vs actual $22.1k + $1.9k + $41.4k → net ≈ **$17.1k/mo combined**. This is the conservative floor.
3. **CAST AI realized (their engine):** projects the same demand under the measured pre-switch **overprovisioning factor (1.6 / 2.2 / 5.25)** vs today's tighter packing → **$41.9k/mo**. Bigger because their baseline captures how bloated provisioning *should* have stayed, not just price.

Every cluster improved its unit economics (ER 0.62–0.86). Corroboration: 392 nodes audited, `addedBy: internal|autoscaler`, 90s empty-node deletion, nightly rebalancing plans with executed add/drain/delete ops in the audit log, and a 100%-consistent arithmetic chain from raw `/cost` items to the summary within $0.

---

## 6. What-if models (no WOOP anywhere; spot presented as an offer)

Anchors (discounted, monthly): helios compute $44.6k + storage $8.8k · integ compute $22.0k + storage $1.8k · kronos compute $1.9k + storage $0.3k. Spot discount assumption: **−60%** on same-class metal (observed live: m6a.24xl spot −62.8%; band ±5 pt). Realized capture of CAST AI's Layman snapshot assumed LOW 50% / MID 70% / HIGH 100%.

### 6.1 S1 — configuration hygiene only (no spot, no WOOP)
Fix evictor ownership, keep nightly rebalancing, family-priority/blocklist c5a, review removal-disabled nodes, add 1c, PV governance.
- helios: −10.2/14.3/20.4% of compute → **$4.5 / $6.4 / $8.9k/mo**
- integ: −11.4/16.0/22.8% → **$2.4 / $3.5 / $4.5k/mo** (+ it stops the 8 failing plans class)
- kronos: −13.4/18.7/26.7% → **$0.26 / $0.36 / $0.52k/mo**
- **Σ MID ≈ $10.3k/mo**

### 6.2 S2 — S1 + spot offer (fallback on, predictions on, reliability +20% cap)
Coverage assumptions: helios 40% of compute (prod-ish, PDB-gated onboarding), integ 70% (test/batch — the obvious candidate), kronos 50%. Applied to post-S1 compute:
- helios: 0.40×0.60×$38.2k ≈ **$9.2k/mo** · integ: 0.70×0.60×$18.5k ≈ **$7.8k/mo** · kronos: 0.50×0.60×$1.58k ≈ **$0.47k/mo**
- **Σ MID ≈ $17.4k/mo on top of S1 → S1+S2 ≈ $27.7k/mo (~−35% of the $79.5k trio bill)**, overall range **$19k–$36k/mo**. Confidence: spot price band observed; coverage is the real unknown → pilot on integ first (zero prod risk), then helios namespaces with PDBs.

Reference ceiling: CAST AI's SpotOnly snapshot (all-spot, listing basis): helios −$48.4k, integ −$12.4k, kronos −$2.6k per month.

### 6.3 S3 — storage hygiene
helios's $8.8k/mo storage ≈ $2.4k node roots (healthy gp3) + **~$6.4k attached EBS/PVs**. Standard PV governance (unattached volumes, oversized claims) typically recovers 10–30% → **$0.6–1.9k/mo helios + smaller amounts elsewhere**.

### 6.4 The WOOP refusal — priced, not preached
Requests run 7–13× usage. If someday reconsidered, WOOP's own recommendation deltas imply provisioned CPU could fall ~55–70% on helios/integ → order **$28–52k/mo** additional (bigger than spot). No action proposed — the constraint stands — but the price tag should be visible at the next review.

---

## 7. Prioritized tuning list

**P1 (week 1 — zero risk, pure configuration, no workload changes):**
1. **Fix the evictor ownership** on all three (decide CAST-managed via `managedByCASTAI=true` upgrade, or deliberately align the self-managed chart: aggressive off, `maxTargetNodesPerCycle 5`, `cycleInterval 10m` on integ/helios scale). Unlocks continuous bin-packing (the Layman −20..27% class).
2. **Integ: enable spot** for integration/test workloads — spot-optional or spot-only template per namespace via pod mutations (no manifest edits), fallback ON. Start at ~50-70% of bursts.
3. **Review the 19 `removal-disabled` nodes** with their owners; unpin what isn't genuinely sacred.
4. **Add `eu-central-1c` subnets** to the three node configurations (capacity pools + spot depth; today's on-demand InsufficientCapacity literally visible in integ audit).

**P2 (month):**
5. **Helios spot**, namespace-gated with PDB contract (multi-replica, maxUnavailable ≥ 1, preStop hooks), spot reliability cap +20%.
6. **Retire the c5a slice**: family prioritization (m6a/m7a/c6a/c7a preferred tier) or c5a blocklist; let the next rebalance rotate it out.
7. **Real cluster CPU limits** (integ especially: sane burst ceiling, e.g. 2× observed p95, instead of 16384).
8. **Storage governance on helios**: unattached/oversized EBS audit of the ~64 TiB non-root pool.

**P3 (hygiene / cosmetics):**
9. Unpin the AMI or switch to `FAMILY_AL2023` family-based selection (also future CLM compatibility; containerd already ✓).
10. Update interruption-prediction type (drop the deprecated `AWSRebalanceRecommendations` literal).
11. Bump WOOP agent v1.10.4 → v1.14.1 (telemetry only, stays non-enforcing); record explicitly in the contract that it remains recommendation-only.
12. Lower kronos rebalancing schedule frequency or leave — its below-threshold "errors" are benign; optionally raise the trigger threshold to make plans meaningful-only.

**Explicitly NOT recommended per constraints:** enabling WOOP/VPA enforcement; any cluster re-onboarding; workload manifest edits (pod mutations cover spot gating).

---

## 8. Going forward — the recurring number to report

Per-cluster × per-month table is reproducible with one command (read-only):

```bash
source .env && python3 scripts/savings/savings_report.py \
  --org-id 07aa3c29-3e1f-44bc-ad60-ceedb878d99a \
  --cluster 419c39e4 --cluster 1ad1a0bf --cluster 6d20eb8e \
  --baseline-days 60 --out .kimchi/docs/si-gsw-clo-ngm-savings-clustermonth.csv
```

Show every review: **actual | frozen-baseline adjusted | CAST AI realized** as three columns, with ER as the trend KPI. Board one-liner: *"Savings are not last-month minus this-month. Demand grew; at the unit prices we froze before CAST AI acted, this demand would have cost X — it cost Y. The difference, fee-deducted, is the floor; CAST AI's own engine reports more."*

## Appendix

- Raw JSON: `cluster-cost-analysis/ngm-{helios,integ,kronos}-eks/` (~25 files each: nodes, policies, node configs, plans, audit, savings, usage, WOOP).
- table CSV: `.kimchi/docs/si-gsw-clo-ngm-savings-clustermonth.csv` (full columns incl. flags).
- Methodology: `.kimchi/docs/siemens-savings-methodology.md`; endpoint verification: `.kimchi/docs/castai-api-savings-endpoints.md`.
- Docs referenced (fetched 2026-10-02): [node templates](https://docs.cast.ai/docs/node-templates.md), [node configuration](https://docs.cast.ai/docs/node-configuration.md), [spot](https://docs.cast.ai/docs/spot.md), [evictor](https://docs.cast.ai/docs/evictor.md), [autoscaler settings](https://docs.cast.ai/docs/autoscaler-settings.md).
- Data quality: kronos short baseline (n=37, lower confidence); W30 `cpuUsed` reflects EKS usage collection (cAdvisor), not billable capacity; `estimated-savings` scenarios are listing-price counterfactuals — never mix bases in customer slides.
